﻿Imports System.IO
Imports System.IO.Stream
Imports System.Text
Public Class Form1
    Dim myFileName As String = ""
    Dim MyNewFile As Stream = Nothing
    Dim MyStream1 As Stream = Nothing
    Dim BufferSize As UInt16 = 1024
    Dim SourceLen As UInt64 = 0
    Dim WordLen As UInt16 = 0
    Dim ToBin As Boolean = False
    Dim LitEnd As Boolean = False
    Dim mySourcePath As String = ""
    Dim mySavePath As String = ""

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Button2.Enabled = False
        'Label3.Visible = False
        'ListBox3.Visible = False
        ComboBox1.SelectedItem = "8 bits"
        ComboBox2.SelectedItem = "binary"
        TextBox1.Text = "File size"
        mySavePath = ""
        mySourcePath = ""
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Button2.Enabled = False

        If (MyStream1 IsNot Nothing) Then
            MyStream1.Close()
        End If
        If (MyNewFile IsNot Nothing) Then
            MyNewFile.Close()
        End If
        'If OpenFileDialog1.InitialDirectory = "" Then OpenFileDialog1.InitialDirectory = mydocpath
        OpenFileDialog1.Filter = "All files|*.*"                           ' "txt files (*.txt)|*.txt|All files (*.*)|*.*"
        OpenFileDialog1.FilterIndex = 1
        OpenFileDialog1.RestoreDirectory = False
        If mySourcePath = "" Then
            OpenFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        Else
            OpenFileDialog1.InitialDirectory = mySourcePath
        End If
        If OpenFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            Try
                MyStream1 = OpenFileDialog1.OpenFile()
                myFileName = OpenFileDialog1.FileName
                mySourcePath = OpenFileDialog1.FileName
                SourceLen = MyStream1.Length
                ' get source file dir and name
                Dim point As UInt16 = 0
                Dim slash As UInt16 = 0
                For i As Int16 = myFileName.Length - 1 To 0 Step -1
                    If myFileName(i) = "." AndAlso point = 0 Then           ' find first "." backward
                        point = i
                    Else
                        If myFileName(i) = "\" Then                         'find first "\" backward
                            slash = i
                            Exit For
                        End If
                    End If
                Next
                If point > 1 AndAlso slash > 1 AndAlso point > slash Then
                    mySourcePath = Mid(myFileName, 1, slash + 1)
                    myFileName = Mid(myFileName, slash + 2, point - slash - 1)
                End If
                '-----------------------
                If (MyStream1 IsNot Nothing) Then
                    ' Insert code to read the stream here. 

                    Dim saveFileDialog1 As New SaveFileDialog()
                    If mySavePath = "" Then
                        saveFileDialog1.InitialDirectory = mySourcePath
                    Else
                        saveFileDialog1.InitialDirectory = mySavePath
                    End If
                    saveFileDialog1.FileName = myFileName + ".coe"
                    ' Save File Dialog
                    saveFileDialog1.Filter = "coe file (*.cap)|*.coe|Text file (*.txt)|*.txt|All files|*.*"      '"txt files (*.txt)|*.txt|All files (*.*)|*.*"
                    saveFileDialog1.FilterIndex = 1

                    saveFileDialog1.RestoreDirectory = False

                    If saveFileDialog1.ShowDialog() = DialogResult.OK Then
                        Try
                            MyNewFile = saveFileDialog1.OpenFile
                            'myFileName = saveFileDialog1.FileName
                        Catch ex As Exception
                            MessageBox.Show("Cannot save file")
                        End Try
                        ' get source file dir and name
                        myFileName = saveFileDialog1.FileName
                        point = 0
                        slash = 0
                        For i As Int16 = myFileName.Length - 1 To 0 Step -1
                            If myFileName(i) = "." AndAlso point = 0 Then           ' find first "." backward
                                point = i
                            Else
                                If myFileName(i) = "\" Then                         'find first "\" backward
                                    slash = i
                                    Exit For
                                End If
                            End If
                        Next
                        If point > 1 AndAlso slash > 1 AndAlso point > slash Then
                            mySavePath = Mid(myFileName, 1, slash + 1)
                            'myFileName = Mid(myFileName, slash + 2, point - slash - 1)
                        End If
                        Button2.Enabled = True
                    Else
                        If (MyStream1 IsNot Nothing) Then
                            MyStream1.Close()
                        End If
                        If (MyNewFile IsNot Nothing) Then
                            MyNewFile.Close()
                        End If
                    End If
                End If
            Catch Ex As Exception
                MessageBox.Show("Cannot open file " + myFileName)
            End Try
        Else
            If (MyStream1 IsNot Nothing) Then
                MyStream1.Close()
            End If
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Button1.Enabled = False
        ComboBox1.Enabled = False
        ComboBox2.Enabled = False
        'ListBox3.Enabled = False
        Button2.Enabled = False
        If ComboBox1.SelectedItem IsNot Nothing And ComboBox2.SelectedItem IsNot Nothing Then
            Select Case ComboBox1.SelectedItem
                Case "8 bits"
                    WordLen = 8
                Case "16 bits"
                    WordLen = 16
                Case "24 bits"
                    WordLen = 24
                Case "32 bits"
                    WordLen = 32
                Case "64 bits"
                    WordLen = 64
                Case "128 bits"
                    WordLen = 128
                Case "256 bits"
                    WordLen = 256
                    'Try
                    '    WordLen = CType(ComboBox1.Text, UInt16)
                    'Catch ex As Exception
                    '    MessageBox.Show("Word length must be a nomber!")
                    '    Button2.Enabled = False
                    '    ComboBox1.Focus()
                    'End Try
            End Select
            Select Case ComboBox2.SelectedItem
                Case "binary"
                    ToBin = True                                                           ' binary =1
                Case "hex"
                    ToBin = False                                                           ' binary =2
                Case Else
                    MessageBox.Show("Suported only binary or hex formats")
                    Button2.Enabled = False
                    ComboBox1.Focus()
            End Select
        Else
            Button2.Enabled = False
            If (MyStream1 IsNot Nothing) Then
                MyStream1.Close()
            End If
            If (MyNewFile IsNot Nothing) Then
                MyNewFile.Close()
            End If
        End If
        Try
            Using sr1 As New BinaryReader(MyStream1)
                Using outfile As BinaryWriter = New BinaryWriter(MyNewFile)     '(mydocpath + "\UserInputFile.txt", True)
                    Dim readBuffer As Byte() = New [Byte](BufferSize) {}
                    Dim BytesToRead As UInt16 = WordLen / 8
                    Dim ascii As New ASCIIEncoding()
                    Dim encodedBytes As Byte()
                    Dim i, j As Int16
                    Dim myB As Byte
                    'Dim correction As UInt16 = 0
                    'If WordLen \ 8 > 0 Then correction = 1
                    Dim line As String = ""
                    If ToBin Then
                        line = "memory_initialization_radix=2;" + vbCrLf
                    Else
                        line = "memory_initialization_radix=16;" + vbCrLf
                    End If
                    encodedBytes = ascii.GetBytes(line)
                    outfile.Write(encodedBytes)
                    encodedBytes = ascii.GetBytes("memory_initialization_vector=" + vbCrLf)
                    outfile.Write(encodedBytes)
                    i = 0
                    Dim writeComa As Boolean = False
                    Dim fileSize As UInt64 = sr1.BaseStream.Length
                    Dim k_end As UInt64 = fileSize

                    If IsNumeric(TextBox1.Text) Then
                        Dim k_end1 As UInt64
                        Try
                            k_end1 = CType(TextBox1.Text, UInt64)
                            k_end1 *= BytesToRead
                            If k_end1 < k_end Then
                                k_end = k_end1
                            End If
                        Catch ex As Exception

                        End Try

                    End If
                    'Dim rest As UInt16 = fileSize Mod BytesToRead
                    'If rest > 0 Then
                    '    MessageBox.Show("There will remain {0} Bytes at File end unconverted!")
                    'End If
                    If k_end > 0 Then
                        k_end -= 1
                    Else
                        If MessageBox.Show("Empty source file!") = DialogResult.OK Then
                            If (MyStream1 IsNot Nothing) Then
                                MyStream1.Close()
                            End If
                            If (MyNewFile IsNot Nothing) Then
                                MyNewFile.Close()
                            End If
                            Return
                        End If
                    End If
                    For k As UInt64 = 0 To k_end
                        Dim b, mask As Byte
                        If writeComa Then
                            writeComa = False
                            i = 0
                            encodedBytes = ascii.GetBytes("," + vbCrLf)
                            outfile.Write(encodedBytes)
                        End If
                        myB = sr1.ReadByte
                        If ToBin Then
                            mask = 128
                            For j = 1 To 8
                                If myB And mask Then
                                    b = &H31
                                Else
                                    b = &H30
                                End If
                                outfile.Write(b)                   'b7
                                mask >>= 1
                            Next j
                        Else
                            b = toASCII((myB And 240) >> 4)
                            outfile.Write(b)
                            b = toASCII(myB And 15)
                            outfile.Write(b)
                        End If

                        i += 1
                        If i = BytesToRead Then writeComa = True
                    Next k
                    encodedBytes = ascii.GetBytes(";" + vbCrLf)
                    outfile.Write(encodedBytes)
                    outfile.Flush()
                End Using
            End Using

        Catch Ex As Exception
            MessageBox.Show("Cannot read from or write to file")
        Finally
            ' Check this again, since we need to make sure we didn't throw an exception on open. 
            If (MyStream1 IsNot Nothing) Then
                MyStream1.Close()
            End If
            If (MyNewFile IsNot Nothing) Then
                MyNewFile.Close()
            End If
        End Try
        Button1.Enabled = True
        ComboBox1.Enabled = True
        ComboBox2.Enabled = True
        Button2.Enabled = False
    End Sub

    Private Function toASCII(ByVal B As Byte) As Byte
        Select Case B
            Case 0
                Return 48
            Case 1
                Return 49
            Case 2
                Return 50
            Case 3
                Return 51
            Case 4
                Return 52
            Case 5
                Return 53
            Case 6
                Return 54
            Case 7
                Return 55
            Case 8
                Return 56
            Case 9
                Return 57
            Case 10
                Return 65
            Case 11
                Return 66
            Case 12
                Return 67
            Case 13
                Return 68
            Case 14
                Return 69
        End Select
        Return 70
    End Function
    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        If (MyStream1 IsNot Nothing) Then
            MyStream1.Close()
        End If
        If (MyNewFile IsNot Nothing) Then
            MyNewFile.Close()
        End If
    End Sub
End Class
